pyre --source-directory . check 
